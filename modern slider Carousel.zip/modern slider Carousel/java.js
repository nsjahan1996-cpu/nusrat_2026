 src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"


const swiper = new Swiper('.mySwiper',{
  loop:true,
  speed:900,
  grabCursor:true,
  pagination:{el:'.swiper-pagination',clickable:true},
  navigation:{nextEl:'.swiper-button-next',prevEl:'.swiper-button-prev'},
  on:{
    slideChangeTransitionStart(){
      gsap.fromTo('.swiper-slide-active .slide-content h2',{y:60,opacity:0},{y:0,opacity:1,duration:.8});
      gsap.fromTo('.swiper-slide-active .slide-content p',{y:40,opacity:0},{y:0,opacity:1,duration:.8,delay:.15});
      gsap.fromTo('.swiper-slide-active .slide-content button',{scale:0,opacity:0},{scale:1,opacity:1,duration:.5,delay:.35,ease:'back.out(1.7)'});
    }
  }
});
